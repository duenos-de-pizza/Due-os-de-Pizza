<?php
session_start();

if (!isset($_SESSION["funcao"])) {
    header("Location: index.php");
    exit();
}

$erro = "";
$sucesso = "";

$conexao = mysqli_connect("localhost", "root", "", "duenos_pizza");
if (!$conexao) {
    die("Erro na conexão com o banco de dados: " . mysqli_connect_error());
}

$clientes = $conexao->query("SELECT idCli, nome FROM clientes ORDER BY nome ASC");
$produtos = $conexao->query("SELECT idProd, nome FROM prod ORDER BY nome ASC");

if (isset($_POST["idCli"], $_POST["idProd"], $_POST["quantidade"], $_POST["status"])) {
    $idCli = (int)$_POST["idCli"];
    $idProd = (int)$_POST["idProd"];
    $quantidade = (int)$_POST["quantidade"];
    $status = $_POST["status"];

    if ($quantidade < 1) {
        $erro = "A quantidade deve ser no mínimo 1.";
    } else {
        $stmt = $conexao->prepare("INSERT INTO pedidos (idCliente, idProd, quantidade, status, dataPedido) VALUES (?, ?, ?, ?, NOW())");
        $stmt->bind_param("iiis", $idCli, $idProd, $quantidade, $status);

        if ($stmt->execute()) {
            $sucesso = "Pedido cadastrado com sucesso!";
        } else {
            $erro = "Erro ao cadastrar pedido.";
        }
        $stmt->close();
    }
}

$conexao->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Cadastrar Pedido | Dueños de Pizza</title>
    <link rel="stylesheet" href="externo.css">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            flex-direction: column;
            font-family: Arial, sans-serif;
            background-color: #F5E9DA;
        }

        h1 {
            font-size: 2em;
            color: #333;
            margin-bottom: 20px;
        }

        .btn {
            padding: 10px 20px;
            background-color: #f80e21ff;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 1em;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .btn:hover {
            background-color: #e20d0dff;
        }

        .erro { color: red; margin-top: 10px; text-align: center; }
        .sucesso { color: green; margin-top: 10px; text-align: center; }

        select, input[type="number"] {
            width: 250px;
            padding: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        form { text-align: center; }
    </style>
</head>
<body>
<section>
    <h1>Cadastrar Pedido</h1>
    <?php if ($erro != "") echo "<p class='erro'>$erro</p>"; ?>
    <?php if ($sucesso != "") echo "<p class='sucesso'>$sucesso</p>"; ?>
    <form action="adicionarped.php" method="post">
        Cliente: 
        <select name="idCli" required>
            <option value="">Selecione um cliente</option>
            <?php while($cliente = $clientes->fetch_assoc()): ?>
                <option value="<?= $cliente['idCli'] ?>"><?= $cliente['nome'] ?></option>
            <?php endwhile; ?>
        </select><br><br>

        Produto: 
        <select name="idProd" required>
            <option value="">Selecione um produto</option>
            <?php while($produto = $produtos->fetch_assoc()): ?>
                <option value="<?= $produto['idProd'] ?>"><?= $produto['nome'] ?></option>
            <?php endwhile; ?>
        </select><br><br>

        Quantidade: <input type="number" name="quantidade" value="1" min="1" required><br><br>

        Status: 
        <select name="status" required>
            <option value="Pendente">Pendente</option>
            <option value="Em preparo">Em preparo</option>
            <option value="Finalizado">Finalizado</option>
        </select><br><br>

        <div style="display: flex; justify-content: center; gap: 10px;">
            <input type="submit" value="Inserir" class="btn">
            <a href="pedidos.php" class="btn">Voltar</a>
        </div>
    </form>
</section>
</body>
</html>
