<?php
session_start();

if (!isset($_SESSION['nickname'])) {
    $_SESSION['msg'] = "Acesso restrito ao gerente!";
    header("Location: index.php");
    exit();
}

$conexao = mysqli_connect("localhost", "root", "", "duenos_pizza");
if (!$conexao) {
    die("Erro na conexão: " . mysqli_connect_error());
}

$erro = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $idPed = $_POST["idPedido"];
    $quantidade = $_POST["quantidade"];
    $status = $_POST["status"];

    if ($quantidade < 1) {
        $erro = "A quantidade deve ser pelo menos 1.";
    } else {
        $stmt = $conexao->prepare("UPDATE pedidos SET quantidade = ?, status = ? WHERE idPedido = ?");
        $stmt->bind_param("isi", $quantidade, $status, $idPed);

        if ($stmt->execute()) {
            $stmt->close();
            $conexao->close();
            header("Location: exibirpedidos.php");
            exit();
        } else {
            $erro = "Erro ao atualizar o pedido.";
        }
    }
}

if (!isset($_GET["idPedido"])) {
    echo "ID do pedido não informado.";
    exit();
}

$idPed = $_GET["idPedido"];
$stmt = $conexao->prepare("SELECT quantidade, status FROM pedidos WHERE idPedido = ?");
$stmt->bind_param("i", $idPed);
$stmt->execute();
$stmt->bind_result($quantidade, $status);
if (!$stmt->fetch()) {
    echo "Pedido não encontrado.";
    exit();
}
$stmt->close();
$conexao->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Alterar Pedido | Dueños de Pizza</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #F5E9DA;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .alterar-pedido-box {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 5px 20px rgba(0,0,0,0.2);
            text-align: center;
            width: 350px;
        }

        h1 {
            color: #333;
            margin-bottom: 15px;
        }

        .btn {
            padding: 10px 20px;
            margin: 5px;
            background-color: #f80e21ff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s;
        }

        .btn:hover {
            background-color: #e20d0dff;
        }

        input[type="number"], select {
            width: 80%;
            padding: 8px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .erro {
            color: red;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
    <div class="alterar-pedido-box">
        <h1>Alterar Pedido</h1>

        <?php if ($erro != "") echo "<p class='erro'>$erro</p>"; ?>

        <form method="post" action="alterarpedido.php?idPed=<?= $idPed ?>">
            <input type="hidden" name="idPed" value="<?= $idPed ?>">

            Quantidade: <br>
            <input type="number" name="quantidade" value="<?= $quantidade ?>" min="1"><br>

            Status: <br>
            <select name="status">
                <option value="Em preparo" <?= $status === "Em preparo" ? "selected" : "" ?>>Em preparo</option>
                <option value="Pronto" <?= $status === "Pronto" ? "selected" : "" ?>>Pronto</option>
                <option value="Entregue" <?= $status === "Entregue" ? "selected" : "" ?>>Entregue</option>
                <option value="Cancelado" <?= $status === "Cancelado" ? "selected" : "" ?>>Cancelado</option>
            </select><br>

            <button type="submit" class="btn">Alterar</button>
            <a href="exibirpedidos.php" class="btn">Voltar</a>
        </form>
    </div>
</body>
</html>
