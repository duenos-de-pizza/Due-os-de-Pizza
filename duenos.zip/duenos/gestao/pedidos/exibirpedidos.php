<?php
session_start();

if (!isset($_SESSION['idFuncionario'])) {
    $_SESSION['msg'] = "Você precisa estar logado como funcionário!";
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Todos os Pedidos | Dueños de Pizza</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #F5E9DA;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding-top: 50px;
        }

        h1, h4 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        .btn {
            margin: 10px;
            padding: 10px 20px;
            background-color: #f80e21ff;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 1em;
            border-radius: 5px;
            transition: background-color 0.3s;
            text-decoration: none;
        }

        .btn:hover {
            background-color: #e20d0dff;
        }

        .pedido-card {
            background: #fff;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0px 5px 15px rgba(0,0,0,0.2);
            margin: 10px 0;
            width: 400px;
        }
    </style>
</head>
<body>

    <h1>Pedidos da Pizzaria</h1>
    <h4>Esses são todos os pedidos cadastrados:</h4>

    <?php
    $conexao = mysqli_connect("localhost", "root", "", "duenos_pizza");
    if (!$conexao) {
        die("Erro na conexão: " . mysqli_connect_error());
    }

    $sql = "SELECT * FROM pedidos";
    $resultado = mysqli_query($conexao, $sql);

    while ($linha = mysqli_fetch_assoc($resultado)) {
        echo '<div class="pedido-card">';
        echo "<b>ID do Pedido:</b> " . $linha["idPedido"] . "<br>";
        echo "<b>ID do Cliente:</b> " . $linha["idCliente"] . "<br>";
        echo "<b>ID do Produto:</b> " . $linha["idProd"] . "<br>";
        echo "<b>Quantidade:</b> " . $linha["quantidade"] . "<br>";
        echo "<b>Data do Pedido:</b> " . $linha["dataPedido"] . "<br>";
        echo "<b>Status:</b> " . $linha["status"] . "<br>";
        echo '</div>';
    }

    mysqli_close($conexao);
    ?>

    <a href="pedidos.php">
        <button class="btn">Voltar</button>
    </a>

</body>
</html>
