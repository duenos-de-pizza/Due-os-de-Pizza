<?php
session_start();

if (!isset($_SESSION['idCli'])) {
    $_SESSION['msg'] = "Você precisa estar logado para finalizar pedidos!";
    header("Location: login.php");
    exit();
}

$conexao = mysqli_connect("localhost", "root", "", "duenos_pizza");
if (!$conexao) {
    die("Erro na conexão com o banco de dados: " . mysqli_connect_error());
}

$idCliente = $_SESSION['idCli'];

$stmt = $conexao->prepare("UPDATE pedidos SET status = 'Em preparo' WHERE idCliente = ?");
$stmt->bind_param("i", $idCliente);

$mensagem = "";
if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        $mensagem = "Pedido finalizado com sucesso! Agora está em preparo.";
    } else {
        $mensagem = "Você não possui pedidos em aberto para finalizar.";
    }
} else {
    $mensagem = "Erro ao finalizar pedido. Tente novamente.";
}

$stmt->close();
$conexao->close();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Finalizar Pedido | Dueños de Pizza</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #F5E9DA;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .mensagem-box {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 5px 20px rgba(0,0,0,0.2);
            text-align: center;
        }
        .btn {
            padding: 10px 20px;
            margin-top: 15px;
            background-color: #f80e21ff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
        }
        .btn:hover {
            background-color: #e20d0dff;
        }
    </style>
</head>
<body>
    <div class="mensagem-box">
        <p><?= $mensagem ?></p>
        <a href="carrinho.php" class="btn">Voltar para o Carrinho</a>
        <a href="index.php" class="btn">Ir para Home</a>
    </div>
</body>
</html>
