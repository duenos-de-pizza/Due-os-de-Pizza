<?php
session_start();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sobre | Dueños de Pizza</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #F5E9DA;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background: transparent !important;
            position: absolute;
            width: 100%;
            z-index: 10; 
            padding-top: 1.2rem;
            padding-bottom: 1.2rem;
        }

        .navbar-brand img {
            height: 80px;
        }

        .navbar .nav-link {
            color: #fff !important; 
            font-weight: 500;
            font-size: 1.1rem;
            padding: 0.8rem 1rem;
            margin: 0 10px;
            padding-bottom: 5px;
        }

        .auth-buttons .btn-login, 
        .auth-buttons .btn-logout {
            background: #e63946;
            padding: 8px 15px;
            border-radius: 5px;
            color: #fff;
            text-decoration: none;
            transition: 0.3s;
        }

        .auth-buttons .btn-login:hover, 
        .auth-buttons .btn-logout:hover {
            background: #d62828;
        }

        .hero {
            height: 100vh; 
            background: url("img/banner.jpeg") no-repeat center center;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
            text-align: center;
            padding: 20px;
        }

        .hero-content {
            background: rgba(0,0,0,0.6);
            padding: 30px;
            border-radius: 15px;
            max-width: 900px;
        }

        .hero-content h1 {
            font-size: 2.5rem;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .hero-content p {
            font-size: 1.1rem;
            line-height: 1.6;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
   
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container-fluid">

                <a class="navbar-brand" href="index.php">
                    <img src="img/logo.png" alt="Dueños de Pizza" height="60">
                </a>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav mx-auto">
                        <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="cardapio.php">Cardápio</a></li>
                        <li class="nav-item"><a class="nav-link" href="carrinho.php">Carrinho</a></li>
                        <li class="nav-item"><a class="nav-link active" href="sobre.php">Sobre</a></li>
                    </ul>            

                    <div class="auth-buttons">
                        <?php if(isset($_SESSION['idCli']) || isset($_SESSION['idFuncionario'])): ?>
                            <a href="logout.php" class="btn-logout">Logout</a>
                        <?php else: ?>
                            <a href="login.php" class="btn-login">Login</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <section class="hero">
        <div class="hero-content">
            <h1>🍕 Dueños de Pizza – A verdadeira realeza da pizza 👑</h1>
            <p>Bem-vindo à <strong>Dueños de Pizza</strong>, onde o sabor é rei e cada fatia conta uma história! Inspirada na tradição italiana, mas com alma latina, nossa pizzaria combina ingredientes de altíssima qualidade com um toque criativo e ousado que transforma cada pizza em uma experiência única.</p>
            <p>Seja você um amante das clássicas <em>Margheritas</em> ou um explorador de sabores exóticos, aqui é o seu lugar. Nossa massa é artesanal, fermentada lentamente para garantir leveza e sabor incomparáveis. Os molhos são feitos com tomates selecionados e temperos frescos, e os recheios vão dos tradicionais aos surpreendentes.</p>
            <p>📍 <strong>Localização:</strong> Rua Giuseppe Verdi, 172 – Bairro Monte Verde, São Paulo – SP</p>
            <p>🕒 <strong>Horário:</strong> Terça a domingo: 17h às 23h (Fechamos às segundas-feiras)</p>
            <p>📱 <strong>Contato & Redes:</strong> Instagram: @duenosdepizza | Facebook: facebook.com/duenosdepizza | WhatsApp: (11) 91234-5678</p>
        </div>
    </section>

    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
