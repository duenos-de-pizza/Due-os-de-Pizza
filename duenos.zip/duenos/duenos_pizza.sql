-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 26/09/2025 às 13:24
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `duenos_pizza`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `clientes`
--

CREATE TABLE `clientes` (
  `idCli` int(11) NOT NULL,
  `nickname` varchar(30) NOT NULL,
  `senha` varchar(60) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `clientes`
--

INSERT INTO `clientes` (`idCli`, `nickname`, `senha`, `nome`, `email`) VALUES
(1, 'Mika', '$2y$10$Ze/2VHbYJ4da6ph5emsPx.OHo8K0eCjmy0bhRiy6tTeoJ/VR1jGju', 'Michelle Amaral Morales de Lima', 'michelle.amaral@gmail.com'),
(4, 'Peterson', '$2y$10$n9Im5MDRys21nJ98Q1ZGUO15IKmQZ3i5dyroIYd9/SvTdDlqewxUm', 'Peterson Morales Fernandes de Lima', 'peter@gmail.com');

-- --------------------------------------------------------

--
-- Estrutura para tabela `funcionarios`
--

CREATE TABLE `funcionarios` (
  `idFuncionario` int(11) NOT NULL,
  `nickname` varchar(30) NOT NULL,
  `senha` varchar(60) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `funcao` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `funcionarios`
--

INSERT INTO `funcionarios` (`idFuncionario`, `nickname`, `senha`, `nome`, `email`, `funcao`) VALUES
(1, 'Adrian', '$2y$10$Vhn0PrhaAJQyEIbA945jSOrQwXY1/Uq/SQoNuw1QlcINsP.AT8kDW', 'Adrian Morales Fernandes de Lima ', 'adrian.mflima@gmail.com', 'gerente'),
(2, 'Vitor', '$2y$10$bwT1xpdZGHwLMEzwr3XA6u/mLXoDamfTRIuH0CGfLU8h5UXPztlbO', 'Vitor Nobrega Ribeiro', 'vitin@gmail.com', 'Repositor'),
(4, 'Antonio', '$2y$10$MShr7JQaKsHvuX3.tywFu.Nz2osSulyr9w.Rm7x6qbM6zMLtilTdK', 'Antonio Miguel', 'antonio@gmail.com', 'Atendente'),
(5, 'Pedro', '$2y$10$l.td8xE3tnXLAuh9KBllHu7H9skSxfVidH8tm35nfVh0Iwr5BVIYy', 'Pedro Neves', 'pedrin@gmail.com', 'Pizzaiolo'),
(6, 'Caio', '$2y$10$3iW.Ry5o4RJBYxy5EYc7TezEmWwzONQ3fBz5ViCtVjRuqXN9rj0xi', 'Caio Madrid', 'caio.madrid@gmail.com', 'Atendente');

-- --------------------------------------------------------

--
-- Estrutura para tabela `pedidos`
--

CREATE TABLE `pedidos` (
  `idPedido` int(11) NOT NULL,
  `idCliente` int(11) NOT NULL,
  `idProd` int(11) NOT NULL,
  `quantidade` int(11) DEFAULT 1,
  `dataPedido` datetime DEFAULT current_timestamp(),
  `status` varchar(50) DEFAULT 'Em preparo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `pedidos`
--

INSERT INTO `pedidos` (`idPedido`, `idCliente`, `idProd`, `quantidade`, `dataPedido`, `status`) VALUES
(27, 1, 2, 1, '2025-09-25 20:43:25', 'Em preparo'),
(28, 1, 1, 1, '2025-09-25 21:05:58', 'Em preparo'),
(29, 1, 1, 1, '2025-09-25 21:06:12', 'Em preparo'),
(30, 1, 1, 3, '2025-09-25 21:07:03', 'Em preparo'),
(31, 1, 3, 1, '2025-09-26 08:07:20', 'Em preparo'),
(32, 1, 1, 1, '2025-09-26 08:07:24', 'Em preparo'),
(33, 1, 2, 1, '2025-09-26 08:07:25', 'Em preparo'),
(34, 1, 1, 2, '2025-09-26 08:18:18', 'Em preparo'),
(35, 1, 2, 1, '2025-09-26 08:18:19', 'Em preparo');

-- --------------------------------------------------------

--
-- Estrutura para tabela `prod`
--

CREATE TABLE `prod` (
  `idProd` int(11) NOT NULL,
  `nome` varchar(30) NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `qtde` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `prod`
--

INSERT INTO `prod` (`idProd`, `nome`, `preco`, `qtde`) VALUES
(1, 'Mussarela', 32.00, 0),
(2, 'Calabresa', 34.00, 0),
(3, 'Portuguesa', 36.00, 0),
(4, 'Marguerita ', 35.00, 0),
(5, 'Frango com Catupiry', 37.00, 0),
(6, 'Bacon com Cheddar', 39.00, 0),
(7, 'Carne Seca com Cream Cheese', 42.00, 0),
(8, 'Quatro Queijos', 38.00, 0),
(9, 'Pepperoni', 40.00, 0),
(10, 'Vegetariana', 36.00, 0),
(11, 'Chocolate com Morango', 32.00, 0),
(12, 'Romeu e Julieta ', 30.00, 0),
(13, 'Banana com Canela', 28.00, 0),
(14, 'Nutella com Morango', 38.00, 0);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`idCli`);

--
-- Índices de tabela `funcionarios`
--
ALTER TABLE `funcionarios`
  ADD PRIMARY KEY (`idFuncionario`);

--
-- Índices de tabela `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`idPedido`),
  ADD KEY `idCliente` (`idCliente`),
  ADD KEY `idProd` (`idProd`);

--
-- Índices de tabela `prod`
--
ALTER TABLE `prod`
  ADD PRIMARY KEY (`idProd`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `clientes`
--
ALTER TABLE `clientes`
  MODIFY `idCli` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `funcionarios`
--
ALTER TABLE `funcionarios`
  MODIFY `idFuncionario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `idPedido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT de tabela `prod`
--
ALTER TABLE `prod`
  MODIFY `idProd` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`idCliente`) REFERENCES `clientes` (`idCli`),
  ADD CONSTRAINT `pedidos_ibfk_2` FOREIGN KEY (`idProd`) REFERENCES `prod` (`idProd`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
